from pydantic import AnyUrl
from typing import Union
import httpx
from qm import (
    Program,
    DictQuaConfig,
    generate_qua_script,
    QuantumMachinesManager,
)
from rich.console import Console
from rich import print_json
from rich.syntax import Syntax
from time import sleep
import json
import toml
import os
import sys
import signal
from datetime import datetime
from dateutil import tz
from rich.table import Table
from qiskit.transpiler import InstructionProperties, Target
from qiskit.circuit import IfElseOp, WhileLoopOp, library
from qiskit.providers.backend import BackendV2
from qiskit.providers import Options
from qiskit.qasm3 import dumps as qasm3_dumps
from importlib import import_module
import pickle
from sys import exit
import jwt
import codecs
from iqcc_cloud_client.state import StateService


class _QiskitBackendQM(BackendV2):
    def __init__(self, target: Target, run):
        super().__init__(
            provider=None,
            name=f"QiskitBackendQM_{target.num_qubits}q",
            description=f"This is a device with {target.num_qubits} qubits.",
            backend_version="",
        )
        self._run = run
        self._target = target

    def run(self, circuit, **options):
        return self._run(
            qasm3_dumps(circuit), **options
        )  ## STILL NOT QISKIT JOB!

    def _default_options(self):
        return Options(num_shots=100, terminal_output=False, debug=False)

    @property
    def target(self):
        return self._target

    @property
    def max_circuits(self):
        return None


def _resolve_files(options: dict):
    hooks = ["pre_hook", "sync_hook", "post_hook"]
    for h in hooks:
        if h in options.keys() and type(options[h]) is str:
            with open(options[h], "r") as f:
                options[h] = f.read()


class IQCC_Cloud(object):
    def __init__(
        self,
        quantum_computer_backend: str = "qc_galilee",
        api_token: str = None,
        url: AnyUrl = "https://cloud.i-qcc.com",
        datastore: str = None,
    ):
        """Client that provides handle to remote quantum computers.

        Args:
            quantum_computer_backend (str, optional): select quantum computer. Defaults to "qc_galilee".
            api_token (str, optional): your secret API access token. If not provided will be read from `~/.config/iqcc_cloud/config.toml`
            url (_type_, optional): online access point. Defaults to "https://cloud.i-qcc.com".
            datastore (_type_, optional): online storage of the data. Set project name or project_name@datastore_URL if not using default datastore
        """
        self.console = Console()
        if api_token is None:
            try:
                data = toml.load(
                    os.path.join(
                        os.path.expanduser("~"),
                        ".config",
                        "iqcc_cloud",
                        "config.toml",
                    )
                )
                api_token = data["tokens"][quantum_computer_backend]
                if "url" in data.keys():
                    url = data["url"]
            except Exception:
                self.console.print("[bold red]Missing IQCC cloud API token")
                self.console.print(
                    ":point_right: Please provide either directly [bold blue]api_token[/bold blue], or set it up using [bold blue]iqcc-cloud setup[/bold blue] command line (terminal) command"
                )
                exit()
        self.headers = {"Authorization": f"Bearer {api_token}"}
        self.token = api_token
        self.qc = quantum_computer_backend
        self.url = url
        self.data_store_url = "https://ds.i-qcc.com"
        self.data_store_project = None
        if datastore is not None:
            a = datastore.split("@")
            self.data_store_project = a[0]
            if len(a) > 1:
                self.data_store_url = a[1]
        self.timeout = 60.0  # timeout of requests
        self.capabilities = None
        if hasattr(QuantumMachinesManager, "set_capabilities_offline"):
            capabilities = self.state.get_latest("qmm_capabilities")
            if capabilities is None:
                load_file = os.path.join(
                        os.path.dirname(os.path.realpath(__file__)), "qc_qw2.pickle"
                    )
                with open(
                    load_file,
                    "rb",
                ) as handle:
                    capabilities = pickle.load(handle)
            else:
                capabilities = pickle.loads(codecs.decode(capabilities.data["data"].encode(), "base64"))
            self.capabilities = capabilities

    @property
    def access_rights(self) -> dict:
        """Specifies access rights to backend for used backend token

        Returns:
            dict: dictionary `{"roles":[...], "projects":[...]}` for roles
                and project access that user has for current backend
        """
        qpu = jwt.decode(
                self.token, options={"verify_signature": False}
            )["qpu"][self.qc]
        rights = {"roles":[], "projects":[]}
        if "access" in qpu.keys():
            rights["roles"]= qpu["access"]
        if "project" in qpu.keys():
            rights["projects"]= qpu["project"]
        return rights

    def execute(
        self,
        qua_program: Union[Program, str] = None,
        qua_config: DictQuaConfig = "",
        terminal_output=False,
        debug=False,
        options: dict = {},
    ) -> dict:
        """Execute QUA program on quantum computer

        Args:
            qua_program (Program): QUA program
            qua_config (DictQuaConfig): QUA config
            terminal_output (bool, optional): Should results be pretty printed
                in terminal. Defaults to False.
            debug (bool, optional): Should final submitted code be pretty
                printed in terminal. Defaults to False.
            options (dict, optional): Backend specific options. Defaults to {}.

        Raises:
            ValueError: _description_

        Returns:
            _dict_: measurement results
        """
        if hasattr(QuantumMachinesManager, "set_capabilities_offline"):
            QuantumMachinesManager.set_capabilities_offline(self.capabilities)
        if qua_config == "":
            binary = "\nconfig = ''\n"
        else:
            if type(qua_program) is Program:
                binary = generate_qua_script(qua_program, qua_config)
            else:
                binary = qua_program + f"\nconfig = {str(qua_config)}\n"

        _resolve_files(options)

        # with open("qua_prog.py", "w") as f:
        #     f.write(binary)
        if debug:
            self.console.print(Syntax(binary, "python"))
        payload = {"qua": binary, "qua_config": qua_config, "options": options}
        return self.__serve_request_spinner(
            "QUA program",
            payload,
            "qua",
            "POST",
            terminal_output=terminal_output,
            debug=debug,
        )

    def openqasm2qua(
        self,
        openqasm3: str,
        num_shots: int = 1000,
        terminal_output=False,
        debug=False,
        options: dict = {},
    ) -> dict:
        """Compile OpenQASM3 code to QUA

        Args:
            openqasm3 (str): OpenQASM3 code
            num_shots (int, optional): Number of shots to repeat the given circuit. Defaults to 1000.
            terminal_output (bool, optional): Should results be pretty printed
                in terminal. Defaults to False.
            debug (bool, optional): Should final submitted code be pretty
                printed in terminal. Defaults to False.
            options (dict, optional): Backend specific options. Defaults to {}.

        Raises:
            ValueError: _description_

        Returns:
            _dict_: measurement results
        """
        request_name = "OpenQASM3 program compilation request"
        payload = {
            "openqasm3": openqasm3,
            "num_shots": num_shots,
            "options": options,
        }
        data = self.__serve_request_spinner(
            request_name,
            payload,
            "openqasm2qua",
            "POST",
            terminal_output=terminal_output,
            debug=debug,
        )
        if debug:
            self.console.print(Syntax(data["result"]["qua"], "python"))
        return data

    def qua_config(
        self, terminal_output=False, debug=False, options: dict = {}
    ) -> DictQuaConfig:
        """Latest QUA configuration

        Args:
            terminal_output (bool, optional): _description_. Defaults to False.
            debug (bool, optional): _description_. Defaults to False.
            options (dict, optional): Backend specific options. Defaults to {}.

        Returns:
            DictQuaConfig: QUA configuration
        """
        request_name = "QUA config request"
        payload = {"options": options}
        data = self.__serve_request_spinner(
            request_name,
            payload,
            "qua_config",
            "GET",
            terminal_output=terminal_output,
            debug=debug,
        )
        return data["result"]

    def quam(
        self, terminal_output=False, debug=False, options: dict = {}
    ) -> object:
        """Latest QUAM (Quantum Abstract Machine) object for the given backend,
        initialized with latest data.

        Args:
            terminal_output (bool, optional): _description_. Defaults to False.
            debug (bool, optional): _description_. Defaults to False.
            options (dict, optional): Backend specific options. Defaults to {}.

        Returns:
            object: _description_
        """
        request_name = "QuAM request"
        payload = {"options": options}
        data = self.__serve_request_spinner(
            request_name,
            payload,
            "quam",
            "GET",
            terminal_output=terminal_output,
            debug=debug,
        )
        try:
            module = import_module(data["result"]["__package"])
            # check version

            if module.__version__ != data["result"]["__version"].replace(
                "v", ""
            ):
                self.console.print(
                    f"Detect quam version [bold blue] {module.__version__}"
                )
                self.console.print(
                    f"Required quam version [bold green] {data['result']['__version'].replace('v', '')}"
                )
                self.console.print(
                    f"Please install quam package for this backend with\n[bold blue]pip install {data['result']['__source']}"
                )

            quam = getattr(
                module,
                data["result"]["__class"],
            )

            from tempfile import TemporaryDirectory

            with TemporaryDirectory() as temp_dir:
                for key in data["result"].keys():
                    if key[0:2] != "__":
                        with open(
                            os.path.join(temp_dir, key + ".json"), "w"
                        ) as f:
                            f.write(json.dumps(data["result"][key]))
                quam_object = quam.load(temp_dir)
            return quam_object
        except Exception as _:
            self.console.print("[bold red]Missing required QuAM library")
            self.console.print(
                f"Please install quam package for this backend with\n[bold blue]pip install {data['result']['__source']}"
            )
            exit()

    def qiskit_backend(
        self, terminal_output=False, debug=False, options: dict = {}
    ) -> BackendV2:
        """Qiskit BackendV2 compatible object.

        NOTE: returned results are still not being compatible with Qiskit job object (WIP)

        Args:
            terminal_output (bool, optional): Pretty print on standard output results. Defaults to False.
            debug (bool, optional): detailed debugging info printing. Defaults to False.
            options (dict, optional): Backend specific options. Defaults to {}.

        Returns:
            BackendV2: _description_
        """
        request_name = "Qiskit request"
        payload = {"options": options}
        data = self.__serve_request_spinner(
            request_name,
            payload,
            "qiskit_backend",
            "GET",
            terminal_output=terminal_output,
            debug=debug,
        )

        data = data["result"]["transpiler_target"]
        target = Target()

        gate_name_mapping = library.get_standard_gate_name_mapping()
        for name, props in data.items():
            gate = gate_name_mapping[name]
            inst_props = {
                tuple(qubits): InstructionProperties(**props_kwargs)
                for qubits, props_kwargs in props
            }
            target.add_instruction(gate, inst_props)

        target.add_instruction(IfElseOp, name="if_else")
        target.add_instruction(WhileLoopOp, name="while_loop")
        target.dt = 1
        return _QiskitBackendQM(target, self.__execute_qasm)

    def __execute_qasm(
        self, qasm3: str, num_shots=100, terminal_output=False, debug=False
    ):
        data = self.openqasm2qua(
            qasm3,
            num_shots=num_shots,
            terminal_output=terminal_output,
            debug=debug,
        )
        if debug:
            self.console.print(Syntax(data["result"]["qua"], "python"))
        data = self.execute(data["result"]["qua"], data["result"]["qua_config"])
        return data

    def __serve_request_spinner(
        self,
        request_name: str,
        payload: dict,
        api_path: str,
        method: str,
        terminal_output=False,
        debug=False,
        options: dict = {},
    ):
        with self.console.status(
            f"[bold blue]Sending {request_name} to {self.url}"
        ) as status:
            if method == "POST":
                r = httpx.post(
                    self.url + f"/{api_path}/{self.qc}",
                    json=payload,
                    headers=self.headers,
                    timeout=self.timeout,
                )
            else:
                r = httpx.get(
                    self.url + f"/{api_path}/{self.qc}",
                    headers=self.headers,
                    timeout=self.timeout,
                )

            if r.status_code == httpx.codes.OK:
                task_id = r.json()["task_id"]
            else:
                self.console.print(f"[bold red]🚨 Error code {r.status_code}")
                self.console.print(f"[bold red]{r.json()['detail']}")
                exit()

            def signal_handler(sig, frame):
                httpx.get(
                    self.url + f"/revoke_task/{task_id}",
                    headers=self.headers,
                    timeout=self.timeout,
                )
                self.console.log("Execution interrupted.")
                self.console.print(f"Task {task_id} revoked upon user request.")
                sys.exit(0)

            try:
                signal.signal(signal.SIGINT, signal_handler)
            except ValueError as _:
                pass

            self.console.log(
                f"{request_name} submitted to [bold blue]{self.qc}[/bold blue] (id = {task_id})"
            )

            status.update(
                status="[bold blue] Waiting for execution", spinner="earth"
            )
            r = httpx.get(
                self.url + f"/task/{task_id}",
                headers=self.headers,
                timeout=self.timeout,
            )
            while r.json()["task_status"] == "PENDING":
                sleep(0.1)
                r = httpx.get(
                    self.url + f"/task/{task_id}",
                    headers=self.headers,
                    timeout=self.timeout,
                )

            self.console.log("Execution started")
            status.update(
                status="[bold green]Executing",
                spinner="bouncingBall",
                spinner_style="green",
            )
            while r.json()["task_status"] in ["RECEIVED", "STARTED"]:
                sleep(0.1)
                r = httpx.get(
                    self.url + f"/task/{task_id}",
                    headers=self.headers,
                    timeout=self.timeout,
                )

            self.console.log("Execution finished")
            r = r.json()
            if r["task_status"] == "SUCCESS":
                if "task_result" in r.keys():
                    results = json.loads(r["task_result"])
                    if "stderr" in results.keys() and results["stderr"] != "":
                        self.console.print(
                            f"[bold red]{request_name} has error:"
                        )
                        self.console.print(f"[bold red]{results['stderr']}")
                    else:
                        self.console.print(
                            f"[bold green]{request_name} successfully executed"
                        )
                else:
                    self.console.print(
                        f"[bold green]{request_name} successfully executed"
                    )
            else:
                self.console.print(f"[bold red]{r['task_status']}")

        results = json.loads(r["task_result"])
        if terminal_output:
            if "result" in results.keys():
                self.console.print("[bold blue] 👍 \tstdout:")
                self.console.print(f"{results['stdout']}")
                if results["stderr"] != "":
                    self.console.print("[bold blue] 🚨\tstderr:")
                    self.console.print(f"[red]{results['stderr']}")
                self.console.print("[bold blue] ⚛️ \tresult")
                special_keys = [
                    "__pre_hook",
                    "__sync_hook",
                    "__post_hook",
                    "__total_python_runtime_seconds",
                    "__qpu_execution_time_seconds",
                ]
                special_data = {}

                for k in special_keys:
                    if k in results["result"].keys():
                        special_data[k] = results["result"][k]
                        results["result"].pop(k)
                print_json(data=results["result"])
                if "__pre_hook" in special_data.keys():
                    self.console.print("[bold blue] 📎 \tpre-hook stdout:")
                    self.console.print(
                        f"{special_data['__pre_hook']['stdout']}"
                    )
                    if special_data["__pre_hook"]["stderr"] != "":
                        self.console.print("[bold blue] 📎 \tpre-hook stderr:")
                        self.console.print(
                            f"[red]{special_data['__pre_hook']['stderr']}"
                        )

                if "__sync_hook" in special_data.keys():
                    self.console.print("[bold blue] 🚀 \tsync-hook stdout:")
                    self.console.print(
                        f"{special_data['__sync_hook']['stdout']}"
                    )
                    if special_data["__sync_hook"]["stderr"] != "":
                        self.console.print("[bold blue] 🚀 \tsync-hook stderr:")
                        self.console.print(
                            f"[red]{special_data['__sync_hook']['stderr']}"
                        )

                if "__post_hook" in special_data.keys():
                    self.console.print("[bold blue] 🏁 \tpost-hook stdout:")
                    self.console.print(
                        f"{special_data['__post_hook']['stdout']}"
                    )
                    if special_data["__post_hook"]["stderr"] != "":
                        self.console.print("[bold blue] 🏁 \tpost-hook stderr:")
                        self.console.print(
                            f"[red]{special_data['__post_hook']['stderr']}"
                        )
                if "__total_python_runtime_seconds" in special_data.keys():
                    self.console.print(
                        "[bold blue] 🕗 🐍 \ttotal Python execution time (s)"
                    )
                    self.console.print(
                        "%.3f" % special_data["__total_python_runtime_seconds"]
                    )
                if "__qpu_execution_time_seconds" in special_data.keys():
                    self.console.print(
                        "[bold blue] 🕗 ⚛️ \tQUA execution time (s)"
                    )
                    self.console.print(
                        "%.3f" % special_data["__qpu_execution_time_seconds"]
                    )
                for key, value in special_data.items():
                    results["result"][key] = value
            else:
                print_json(data=results)

        return results

    def summary(self):
        """Prints on standard output information on the backend and returns
        dictionary with that information.

        Returns:
            dict: backend information
        """
        request = self.__serve_request_spinner(
            "Backend summary request", {}, "summary", "GET"
        )
        self.console.rule(f"[bold blue] {self.qc}[/bold blue]")
        self.console.print("[bold]Capabilities:")
        for x in request["result"]["supports"]:
            self.console.print(f"[bold green] \u2713 [/bold green] {x}")
        if "qubit_information" in request["result"].keys():
            table = Table(title="Supported native gates")

            table.add_column(
                "Gate", justify="right", style="cyan", no_wrap=True
            )
            table.add_column("Qubits", style="magenta")
            table.add_column("Note", justify="right", style="green")

            for key, value in request["result"]["qubit_information"].items():
                qubits = []
                for v in value:
                    qubits.append(v[0])
                table.add_row(f"[bold]{key}[/bold]", str(qubits)[1:-1], "")
            self.console.print(table)

        if "calibration_modified" in request["result"].keys():
            to_zone = tz.tzlocal()
            self.console.print(
                f"[bold]Last calibration modification[/bold]: {datetime.fromtimestamp(request['result']['calibration_modified']).astimezone(to_zone).strftime('%c')}"
            )
        self.console.rule()
        return request["result"]

    @property
    def state(
        self, state_service_url="https://state.i-qcc.com"
    ) -> StateService:
        """Service providing state information

        Args:
            state_service_url (str, optional): URL of the state service. Defaults to "https://state.i-qcc.com".

        Returns:
            StateService: Provides state of the backends
        """
        return StateService(
            url=state_service_url, backend=self.qc, headers=self.headers
        )

    @property
    def data(self) -> StateService:
        """Service providing data access. Requires that `datastore` is set
        initializing backend client.

        Returns:
            StateService: Stores, provides and queries data for the project.
        """
        if self.data_store_project is None or self.data_store_url is None:
            raise ValueError(
                "Define data_store when initializing backend to use this method."
            )
        headers = self.headers.copy()
        headers["iqcc-datastore-project"] = self.data_store_project
        return StateService(
            url=self.data_store_url, backend=self.qc, headers=headers
        )
